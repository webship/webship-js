Webship-js sample archive.
It holds two reports.
